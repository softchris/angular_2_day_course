(function(module){

	'use strict';

	module.service('Product', ProductModel );

	function ProductModel(){
		function Product(dto){
			this.name = dto.name;
		}

		return Product;
	}

})(angular.module('app.products'));