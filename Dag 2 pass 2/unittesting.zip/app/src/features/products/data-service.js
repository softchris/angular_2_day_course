(function(module){

	'use strict';

	module.service('dataService', DataService );

	DataService.$inject = [ '$http' ];

	function DataService($http){
		return {
			getProducts : getProducts
		};

		function getProducts(params){
			if(params){
				return $http.get('/products/' + params.id);	
			} else {
				return $http.get('/products/');
			}
		}
	}

})(angular.module('app.products'));