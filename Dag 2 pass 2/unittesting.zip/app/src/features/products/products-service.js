(function(module){

	'use strict';

	module.service('productService', ProductService );

	function ProductService(){
		return {
			calcPriceAfterDiscount : calcPriceAfterDiscount
		};

		function calcPriceAfterDiscount(price, discount){
			return price * ( 1 - (discount /100 ) );
		}
	}

})(angular.module('app.products'));