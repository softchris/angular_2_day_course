(function(module){
	'use strict';

	module
		.controller('cartController', CartController );

	function CartController($scope, cartService){
		var cartLimitTotalPrice = 400;

		$scope.add = add;

		function add(item){
			if(getTotalPrice() + item.price <= cartLimitTotalPrice) {
				cartService.addItem( item );
			}
		}

		function getTotalPrice(){
			var items = cartService.getItems();
			var sum = 0;
			for(var i=0; i< items.length; i++){
				sum += items[i].price;
			}

			return sum;
		}
	}

	CartController.$inject = [ '$scope','cartService' ];


})(angular.module('app.cart'));