(function(module){

	'use strict';

	module.service('cartService', CartService );

	CartService.$inject = ['Product','$http'];

	function CartService(Product, $http){
		var items = [];

		return {
			addItem : addItem,
			getItems : getItems
		};

		function addItem(item){
			items.push( new Product( item ) );
		}

		function getItems(){	
			return items;
		}
	}

})(angular.module('app.cart'));