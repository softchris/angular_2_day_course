describe('given a product service', function(){
	var productService;

	beforeEach(module('app.products'));

	beforeEach(inject(function(_productService_){
		productService = _productService_;
	}));

	it('when given a 25% discount', function(){
		
		// ARRANGE
		originalPrice = 100;
		discount = 25;

		// ACT
		var actual = productService.calcPriceAfterDiscount( originalPrice, discount );


		// ASSERT
		expect( actual ).toBe( originalPrice * 0.75 );
	});
});