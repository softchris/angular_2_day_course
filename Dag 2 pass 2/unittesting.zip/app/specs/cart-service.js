describe('given a cart', function(){
	var cartService,
		$provide;
	//beforeEach(module('app.products'))
	beforeEach(module('app.cart'))

	beforeEach(function(){
		var mockProduct = function(dto){
			this.a = dto.a;	
		}

		module(function(_$provide_){
			$provide = _$provide_;
			$provide.value('Product', mockProduct);
		});

		inject(function(_cartService_){
			cartService = _cartService_;	
		});
	});


	it('when adding an item to cart', function(){
		var noBefore = cartService.getItems().length;
		cartService.addItem({ name : 'tomato' });

		var noAfter = cartService.getItems().length;

		expect( noBefore +1 ).toBe( noAfter );
	})
})