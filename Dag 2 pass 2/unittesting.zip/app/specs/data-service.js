describe('test data service', function(){
	var dataService,
		httpBackend;

	beforeEach(module('app.products'));

	beforeEach(function(){
		inject(function($httpBackend, _dataService_){
			dataService = _dataService_;
			httpBackend = $httpBackend;

			$httpBackend
				.when('GET', '/products/')
                .respond([{ name : 'tomato', id : 1 },{ name : 'cucumber', id : 2 }]);

              $httpBackend
				.when('GET', '/products/2')
                .respond([{ name : 'cucumber', id : 2 }]);
		});
	});

	it('test - is right list method called', function(){
		
		dataService.getProducts().then(function(respond){
			expect(respond.data.length).toBe( 2 );
		});
		httpBackend.flush();
	});

	it('test - is detail method called', function(){
		
		dataService.getProducts({ id : 2 }).then(function(respond){
			expect(respond.data.length).toBe( 1 );
			expect(respond.data[0].id).toBe( 2 );
		});

		httpBackend.flush();
	})
})