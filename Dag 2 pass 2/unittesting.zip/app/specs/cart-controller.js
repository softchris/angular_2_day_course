describe('given a cart', function(){
	var cartService,
		$provide,
		cartController,
		scope,
		mockCartService;
	//beforeEach(module('app.products'))
	beforeEach(module('app.cart'))

	beforeEach(function(){
		mockCartService = {
			addItem : function(){

			},
			getItems : function(){
				return [];
			}
		}

		module(function(_$provide_){
			$provide = _$provide_;
			//$provide.value('cartService', mockCartService);
		});

		inject(function($controller, $rootScope){
			spyOn(mockCartService, 'addItem');

			scope = $rootScope.$new();
			cartController = $controller('cartController',{
				$scope : scope,
				cartService : mockCartService
			});	
		});
	});


	it('when adding an item to cart - and limit not reached', function(){
		console.log('trt');
		scope.add( { name : 'test', price : 11 } );
		expect(mockCartService.addItem).toHaveBeenCalled();
		// cartService::addItem was called
	});

	it('when adding an item to cart - and limit reached', function(){
		console.log('trt');
		scope.add( { name : 'test', price : 401 } );
		expect(mockCartService.addItem.calls.count()).toEqual(0);
		// cartService::addItem was NOT called
	})
})