(function(){
	'use strict';

	angular.module('app.products',[]);
	angular.module('app.cart',[]);

	angular.module('app',[
		'app.products',
		'app.cart'
	])
	.controller('appCtrl', function(productService){
		$scope.test = 'test';
	});

})();